﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace SILEX.Controllers
{
    public class SilexController : Controller
    {
        // GET: SilexController
        public ActionResult Index()
        {
            return View();
        }

        // GET: SilexController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: SilexController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: SilexController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: SilexController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: SilexController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: SilexController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: SilexController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
